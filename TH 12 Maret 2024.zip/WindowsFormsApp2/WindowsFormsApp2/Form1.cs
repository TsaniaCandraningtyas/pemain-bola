﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        DataTable dtCountry = new DataTable();
        DataTable dtTeam = new DataTable();
        List<string> country = new List<string>();
        Dictionary<string, List<string>> teamsByCountry = new Dictionary<string, List<string>>();
        public Form1()
        {
            InitializeComponent();
            InitializeData();
        }
        private void InitializeData()
        {
            teamsByCountry.Add("Germany", new List<string> { "SC Freiburg", "Hamburger SV" });
            teamsByCountry.Add("Inggris", new List<string> { "Manchester United", "Manchester City" });
            foreach (string country in teamsByCountry.Keys)
            {
                cb_Country.Items.Add(country);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string newCountry = tb_CountryName.Text;
            cb_Country.Items.Add(newCountry);
            teamsByCountry.Add(newCountry, new List<string>());
            tb_CountryName.Clear();
            string selectedCountry = cb_Country.SelectedItem.ToString();
            string newTeam = tb_TeamName.Text;
            cb_Team.Items.Add(newTeam);
            teamsByCountry[selectedCountry].Add(newTeam);
            tb_TeamName.Clear();
            //tb_City.Clear();
        }

        private void bt_Remove_Click(object sender, EventArgs e)
        {
            if(listbox_Nama.Items.Count < 11)
            {
                MessageBox.Show("Harus Lebih Dari 11");
            }
            else
            {
                foreach (var item in listbox_Nama.SelectedItems.Cast<string>().ToList())
                {
                    listbox_Nama.Items.Remove(item);
                }
            }
        }

        private void cb_Country_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCountry = cb_Country.SelectedItem.ToString();
            cb_Team.Items.Clear();
            if (teamsByCountry.ContainsKey(selectedCountry))
            {
                foreach (string team in teamsByCountry[selectedCountry])
                {
                    cb_Team.Items.Add(team);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        string abe = "tsania";
        private void bt_Add2_Click(object sender, EventArgs e)
        {
            listbox_Nama.Items.Add($"[{tb_PlayerNumber.Text}] {tb_PlayerName.Text}, {tb_PlayerPosition.Text}");
            for (int i = 0; i < listbox_Nama.Items.Count; i++)
            {
                if (tb_PlayerPosition.Text == listbox_Nama.Items[i].ToString())
                {
                    abe = "cacing";
                }
            }
            if (abe != "cacing")
            {
                listbox_Nama.Items.Add(tb_PlayerPosition.Text);
                abe = "tsania";
            }
            else
            {
                MessageBox.Show("Posisi Harus Berbeda");
                abe = "tsania";
            }
        }

        private void cb_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            listbox_Nama.Items.Clear();
            string selectedItem = cb_Team.SelectedItem.ToString();
            switch (selectedItem)
            {
                case "SC Freiburg":
                    listbox_Nama.Items.Add("[1] Noah Atubolu GK");
                    listbox_Nama.Items.Add("[2] Philipp Lienhart DF");
                    listbox_Nama.Items.Add("[7] Noah Weißhaupt MF");
                    listbox_Nama.Items.Add("[9] Lucas Höler FW");
                    listbox_Nama.Items.Add("[4] Kenneth Schmidt DF");
                    listbox_Nama.Items.Add("[6] Attila Szalai DF");
                    listbox_Nama.Items.Add("[8] Maximilian Eggestein MF");
                    listbox_Nama.Items.Add("[11] Daniel-Kofi Kyereh MF");
                    listbox_Nama.Items.Add("[21] Florian Müller GK");
                    listbox_Nama.Items.Add("[22] Roland Sallai MF");
                    listbox_Nama.Items.Add("[20] Junior Adamu FW");
                    break;
                case "Hamburger SV":
                    listbox_Nama.Items.Add("[1] Daniel H. Fernandes GK");
                    listbox_Nama.Items.Add("[2] William Mikelbrencis DF");
                    listbox_Nama.Items.Add("[6] Łukasz Poręba MF");
                    listbox_Nama.Items.Add("[9] Robert Glatzel FW");
                    listbox_Nama.Items.Add("[4] Sebastian Schonlau DF");
                    listbox_Nama.Items.Add("[5] Dennis Hadžikadunić DF");
                    listbox_Nama.Items.Add("[8] László Bénes MF");
                    listbox_Nama.Items.Add("[17] Masaya Okugawa MF");
                    listbox_Nama.Items.Add("[19] Matheo Raab GK");
                    listbox_Nama.Items.Add("[18] Bakery Jatta MF");
                    listbox_Nama.Items.Add("[11] R. Königsdörffer FW");
                    break;
                case "Manchester United":
                    listbox_Nama.Items.Add("[1] Altay Bayındır GK");
                    listbox_Nama.Items.Add("[2] Victor Lindelöf DF");
                    listbox_Nama.Items.Add("[4] Sofyan Amrabat MF");
                    listbox_Nama.Items.Add("[5] Harry Maguire DF");
                    listbox_Nama.Items.Add("[6] Lisandro Martínez DF");
                    listbox_Nama.Items.Add("[7] Mason Mount MF");
                    listbox_Nama.Items.Add("[8] Bruno Fernandes MF");
                    listbox_Nama.Items.Add("[9] Anthony Martial FW");
                    listbox_Nama.Items.Add("[10] Marcus Rashford FW");
                    listbox_Nama.Items.Add("[11] Rasmus Højlund FW");
                    listbox_Nama.Items.Add("[12] Tyrell Malacia DF");
                    break;
                case "Manchester City":
                    listbox_Nama.Items.Add("[2] Kyle Walker DF");
                    listbox_Nama.Items.Add("[3] Rúben Dias DF");
                    listbox_Nama.Items.Add("[5] John Stones DF");
                    listbox_Nama.Items.Add("[6] Nathan Aké DF");
                    listbox_Nama.Items.Add("[8] Mateo Kovačić MF");
                    listbox_Nama.Items.Add("[9] Erling Haaland FW");
                    listbox_Nama.Items.Add("[10] Jack Grealish MF");
                    listbox_Nama.Items.Add("[11] Jérémy Doku MF");
                    listbox_Nama.Items.Add("[16] Rodri MF");
                    listbox_Nama.Items.Add("[17] Kevin De Bruyne MF");
                    listbox_Nama.Items.Add("[18] Stefan Ortega GK");
                    break;
            }
        }
    }
}
