﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Country = new System.Windows.Forms.Label();
            this.lb_Team = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lb_TeamName = new System.Windows.Forms.Label();
            this.lb_TeamCountry = new System.Windows.Forms.Label();
            this.lb_TeamCity = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tb_TeamName = new System.Windows.Forms.TextBox();
            this.tb_CountryName = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tb_PlayerName = new System.Windows.Forms.TextBox();
            this.tb_PlayerNumber = new System.Windows.Forms.TextBox();
            this.tb_PlayerPosition = new System.Windows.Forms.TextBox();
            this.bt_Add1 = new System.Windows.Forms.Button();
            this.bt_Add2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.bt_Remove = new System.Windows.Forms.Button();
            this.listbox_Nama = new System.Windows.Forms.ListBox();
            this.cb_Country = new System.Windows.Forms.ComboBox();
            this.cb_Team = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lb_Country
            // 
            this.lb_Country.AutoSize = true;
            this.lb_Country.Location = new System.Drawing.Point(20, 90);
            this.lb_Country.Name = "lb_Country";
            this.lb_Country.Size = new System.Drawing.Size(43, 13);
            this.lb_Country.TabIndex = 0;
            this.lb_Country.Text = "Country";
            // 
            // lb_Team
            // 
            this.lb_Team.AutoSize = true;
            this.lb_Team.Location = new System.Drawing.Point(20, 125);
            this.lb_Team.Name = "lb_Team";
            this.lb_Team.Size = new System.Drawing.Size(34, 13);
            this.lb_Team.TabIndex = 1;
            this.lb_Team.Text = "Team";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(110, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Soccer Team List";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(385, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Adding Team";
            // 
            // lb_TeamName
            // 
            this.lb_TeamName.AutoSize = true;
            this.lb_TeamName.Location = new System.Drawing.Point(291, 90);
            this.lb_TeamName.Name = "lb_TeamName";
            this.lb_TeamName.Size = new System.Drawing.Size(65, 13);
            this.lb_TeamName.TabIndex = 4;
            this.lb_TeamName.Text = "Team Name";
            // 
            // lb_TeamCountry
            // 
            this.lb_TeamCountry.AutoSize = true;
            this.lb_TeamCountry.Location = new System.Drawing.Point(291, 121);
            this.lb_TeamCountry.Name = "lb_TeamCountry";
            this.lb_TeamCountry.Size = new System.Drawing.Size(73, 13);
            this.lb_TeamCountry.TabIndex = 5;
            this.lb_TeamCountry.Text = "Team Country";
            // 
            // lb_TeamCity
            // 
            this.lb_TeamCity.AutoSize = true;
            this.lb_TeamCity.Location = new System.Drawing.Point(291, 149);
            this.lb_TeamCity.Name = "lb_TeamCity";
            this.lb_TeamCity.Size = new System.Drawing.Size(54, 13);
            this.lb_TeamCity.TabIndex = 6;
            this.lb_TeamCity.Text = "Team City";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(525, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Player Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(525, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Player Number";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(525, 153);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Player Position";
            // 
            // tb_TeamName
            // 
            this.tb_TeamName.Location = new System.Drawing.Point(362, 87);
            this.tb_TeamName.Name = "tb_TeamName";
            this.tb_TeamName.Size = new System.Drawing.Size(125, 20);
            this.tb_TeamName.TabIndex = 10;
            // 
            // tb_CountryName
            // 
            this.tb_CountryName.Location = new System.Drawing.Point(362, 118);
            this.tb_CountryName.Name = "tb_CountryName";
            this.tb_CountryName.Size = new System.Drawing.Size(125, 20);
            this.tb_CountryName.TabIndex = 11;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(362, 146);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(125, 20);
            this.textBox3.TabIndex = 12;
            // 
            // tb_PlayerName
            // 
            this.tb_PlayerName.Location = new System.Drawing.Point(607, 88);
            this.tb_PlayerName.Name = "tb_PlayerName";
            this.tb_PlayerName.Size = new System.Drawing.Size(133, 20);
            this.tb_PlayerName.TabIndex = 13;
            // 
            // tb_PlayerNumber
            // 
            this.tb_PlayerNumber.Location = new System.Drawing.Point(607, 114);
            this.tb_PlayerNumber.Name = "tb_PlayerNumber";
            this.tb_PlayerNumber.Size = new System.Drawing.Size(133, 20);
            this.tb_PlayerNumber.TabIndex = 14;
            // 
            // tb_PlayerPosition
            // 
            this.tb_PlayerPosition.Location = new System.Drawing.Point(607, 147);
            this.tb_PlayerPosition.Name = "tb_PlayerPosition";
            this.tb_PlayerPosition.Size = new System.Drawing.Size(133, 20);
            this.tb_PlayerPosition.TabIndex = 15;
            // 
            // bt_Add1
            // 
            this.bt_Add1.Location = new System.Drawing.Point(390, 185);
            this.bt_Add1.Name = "bt_Add1";
            this.bt_Add1.Size = new System.Drawing.Size(75, 23);
            this.bt_Add1.TabIndex = 16;
            this.bt_Add1.Text = "Add";
            this.bt_Add1.UseVisualStyleBackColor = true;
            this.bt_Add1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bt_Add2
            // 
            this.bt_Add2.Location = new System.Drawing.Point(642, 185);
            this.bt_Add2.Name = "bt_Add2";
            this.bt_Add2.Size = new System.Drawing.Size(75, 23);
            this.bt_Add2.TabIndex = 17;
            this.bt_Add2.Text = "Add";
            this.bt_Add2.UseVisualStyleBackColor = true;
            this.bt_Add2.Click += new System.EventHandler(this.bt_Add2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(622, 39);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Adding Player";
            // 
            // bt_Remove
            // 
            this.bt_Remove.Location = new System.Drawing.Point(31, 325);
            this.bt_Remove.Name = "bt_Remove";
            this.bt_Remove.Size = new System.Drawing.Size(75, 23);
            this.bt_Remove.TabIndex = 19;
            this.bt_Remove.Text = "Remove";
            this.bt_Remove.UseVisualStyleBackColor = true;
            this.bt_Remove.Click += new System.EventHandler(this.bt_Remove_Click);
            // 
            // listbox_Nama
            // 
            this.listbox_Nama.FormattingEnabled = true;
            this.listbox_Nama.Location = new System.Drawing.Point(31, 198);
            this.listbox_Nama.Name = "listbox_Nama";
            this.listbox_Nama.Size = new System.Drawing.Size(231, 121);
            this.listbox_Nama.TabIndex = 20;
            // 
            // cb_Country
            // 
            this.cb_Country.FormattingEnabled = true;
            this.cb_Country.Location = new System.Drawing.Point(69, 87);
            this.cb_Country.Name = "cb_Country";
            this.cb_Country.Size = new System.Drawing.Size(177, 21);
            this.cb_Country.TabIndex = 21;
            this.cb_Country.SelectedIndexChanged += new System.EventHandler(this.cb_Country_SelectedIndexChanged);
            // 
            // cb_Team
            // 
            this.cb_Team.FormattingEnabled = true;
            this.cb_Team.Location = new System.Drawing.Point(69, 121);
            this.cb_Team.Name = "cb_Team";
            this.cb_Team.Size = new System.Drawing.Size(177, 21);
            this.cb_Team.TabIndex = 22;
            this.cb_Team.SelectedIndexChanged += new System.EventHandler(this.cb_Team_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cb_Team);
            this.Controls.Add(this.cb_Country);
            this.Controls.Add(this.listbox_Nama);
            this.Controls.Add(this.bt_Remove);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.bt_Add2);
            this.Controls.Add(this.bt_Add1);
            this.Controls.Add(this.tb_PlayerPosition);
            this.Controls.Add(this.tb_PlayerNumber);
            this.Controls.Add(this.tb_PlayerName);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.tb_CountryName);
            this.Controls.Add(this.tb_TeamName);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lb_TeamCity);
            this.Controls.Add(this.lb_TeamCountry);
            this.Controls.Add(this.lb_TeamName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lb_Team);
            this.Controls.Add(this.lb_Country);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Country;
        private System.Windows.Forms.Label lb_Team;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lb_TeamName;
        private System.Windows.Forms.Label lb_TeamCountry;
        private System.Windows.Forms.Label lb_TeamCity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tb_TeamName;
        private System.Windows.Forms.TextBox tb_CountryName;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox tb_PlayerName;
        private System.Windows.Forms.TextBox tb_PlayerNumber;
        private System.Windows.Forms.TextBox tb_PlayerPosition;
        private System.Windows.Forms.Button bt_Add1;
        private System.Windows.Forms.Button bt_Add2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button bt_Remove;
        private System.Windows.Forms.ListBox listbox_Nama;
        private System.Windows.Forms.ComboBox cb_Country;
        private System.Windows.Forms.ComboBox cb_Team;
    }
}

